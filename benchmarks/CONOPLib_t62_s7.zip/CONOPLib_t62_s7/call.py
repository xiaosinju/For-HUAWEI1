import ctypes
import os
from savedat import savedat
import pandas as pd
import numpy as np
import configparser



def loadsoln():
    df = pd.read_csv('soln.dat', delim_whitespace=True, header=None)
    soln_matrix = df.loc[:].values
    for i in range(0, len(soln_matrix)):
        soln[i] = (soln_matrix[i][0]-1)*2 + soln_matrix[i][1] - 1
    print('loadSOLN', soln)

def getPosition(soln):
    for i in range(0, nevent):
        position[soln[i]] = i


def checkFADLAD(soln):
    getPosition(soln)
    for i in range(0, len(FadLad)):
        if position[FadLad[i][0]] > position[FadLad[i][1]]:
            return False
    return True


def checkcoex(soln):
    getPosition(soln)
    for i in range(0, len(coex)):
        if position[coex[i][0]] > position[coex[i][1] + 1] or position[coex[i][1]] > position[coex[i][0] + 1]:
            return False
    return True


def repair(soln):
    getPosition(soln)
    rank = 0
    # solve fadlad for the same taxa
    for i in range(0, nevent - 1, 2):
        if position[i] > position[i + 1]:
            soln[int(position[i])], soln[int(position[i + 1])] = soln[int(position[i + 1])], soln[int(position[i])]
            print("here1")
    while rank != nevent:
        # if perm[rank] is FAD
        if(soln[rank] % 2 == 0):
            # search for LAD
            lrank = int(position[soln[rank] + 1])
            trank = lrank + 1
            while(trank != nevent):
                if(soln[trank] % 2 == 0 and ([soln[trank], soln[lrank]] in FadLad.tolist() or [soln[trank], soln[rank]] in coex.tolist() or [soln[trank], soln[rank]] in coex.tolist())):
                    soln[trank], soln[lrank] = soln[lrank], soln[trank]
                    position[soln[lrank]], position[soln[trank]] = position[soln[trank]], position[soln[lrank]]
                    # getPosition(soln)
                trank += 1
        rank += 1


class EarthBench:
    def __init__(self):
        self.so = ctypes.CDLL('CONOPLib.so')
        nevent = 124
        position = np.zeros(nevent)
        soln = np.arange(0, nevent, 1)
        df = pd.read_csv('Fb4L.dat', delim_whitespace=True, header=None)
        FadLad = df.loc[:].values
        df = pd.read_csv('coex.dat', delim_whitespace=True, header=None)
        coex = df.loc[:].values
        for i in range(0, len(FadLad)):
            FadLad[i][0] = FadLad[i][0] * 2
            FadLad[i][1] = FadLad[i][1] * 2 +1

        for i in range(0, len(coex)):
            coex[i][0] = coex[i][0] * 2
            coex[i][1] = coex[i][1] * 2

    def __call__(self, x):
        assert x.ndim == 1
        # check and repair
        log.debug('checkFADLAD: {}'.format(checkFADLAD(x)))
        log.debug('checkcoex: {}'.format(checkcoex(x)))
        repair(x)
        assert checkFADLAD(x) == True and checkcoex(x) == True

        # evaluate
        carrary = (ctypes.c_int * len(soln))(*soln)
        self.so.
        

# loadsoln()
print('checkFADLAD:', checkFADLAD(soln))
print('checkcoex', checkcoex(soln))
repair(soln)
carrary = (ctypes.c_int * len(soln))(*soln)

so.getPenalty.restype=ctypes.c_double
# Call the getPenalty exposed by dynamic link library
pen1 = so.getPenalty(carrary,len(soln))

print ("pen0=%d"%(pen1))
print

soln = [2, 4, 3, 5, 6, 7, 8, 14, 15, 10, 9, 12, 26, 16, 18, 22, 13, 17, 19, 28, 32, 24, 30, 40, 44, 46, 0, 48, 42, 36, 20, 37, 31, 23, 122, 38, 52, 34, 50, 56, 21, 1, 29, 39, 25, 53, 123, 45, 58, 27, 62, 54, 47, 57, 11, 59, 55, 66, 60, 68, 72, 64, 73, 63, 65, 67, 76, 51, 35, 33, 41, 70, 78, 71, 79, 82, 74, 84, 61, 77, 80, 88, 75, 43, 69, 92, 86, 90, 87, 91, 112, 93, 49, 89, 108, 104, 85, 113, 96, 110, 111, 94, 102, 103, 98, 100, 106, 97, 95, 114, 107, 101, 105, 109, 116, 81, 83, 118, 99, 120, 119, 115, 121, 117]
print('checkFADLAD:', checkFADLAD(soln))
print('checkcoex', checkcoex(soln))
repair(soln)
carrary = (ctypes.c_int * len(soln))(*soln)

so.getPenalty.restype=ctypes.c_double
# Call the getPenalty exposed by dynamic link library
pen1 = so.getPenalty(carrary,len(soln))

print ("pen1=%d"%(pen1))
print


soln = [22, 4, 8, 2, 6, 5, 16, 10, 12, 14, 18, 15, 26, 19, 17, 36, 44, 20, 9, 34, 13, 32, 58, 30, 7, 28, 46, 40, 24, 52, 42, 56, 50, 3, 72, 48, 0, 54, 53, 122, 38, 25, 39, 31, 27, 29, 45, 60, 70, 62, 59, 76, 68, 92, 55, 64, 78, 11, 96, 90, 66, 51, 118, 88, 1, 35, 41, 47, 112, 57, 98, 82, 104, 80, 74, 79, 106, 94, 63, 71, 84, 86, 73, 87, 110, 93, 61, 67, 23, 116, 37, 75, 100, 33, 114, 108, 69, 43, 97, 102, 21, 105, 101, 111, 91, 113, 123, 109, 81, 120, 107, 121, 65, 89, 99, 85, 119, 117, 95, 49, 83, 77, 103, 115]
print('checkFADLAD:', checkFADLAD(soln))
print('checkcoex', checkcoex(soln))
repair(soln)
carrary = (ctypes.c_int * len(soln))(*soln) 

pen2 = so.getPenalty(carrary,len(soln))

print ("pen2=%d"%(pen2))

print



print ("---Done---")


