
class Output
{
	public:
		static void STARTOUT(int myperm[]);
		static void STEPOUT(int myperm[]);
		static void COEXOUT();
		static void FADLADOUT();
};

