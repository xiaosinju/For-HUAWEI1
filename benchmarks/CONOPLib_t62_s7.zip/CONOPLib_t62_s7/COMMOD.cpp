#include"COMMOD.h"

COMMOD* COMMOD::g_singleton=NULL;
